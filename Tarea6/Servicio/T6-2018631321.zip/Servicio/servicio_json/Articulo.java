package servicio_json;

public class Articulo
{
  String nombre;
  String descripcion;
  float precio;
  int relevancia;
  int existencia;
  byte[] foto;
}
