package servicio_json;

public class ArticuloConsulta
{
  int id_articulo;
  String nombre;
  String descripcion;
  float precio;
  int existencia;
  byte[] foto;
}
