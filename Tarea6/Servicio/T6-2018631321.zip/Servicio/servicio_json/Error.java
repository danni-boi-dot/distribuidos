
package servicio_json;

public class Error
{
	String message;

	Error(String message)
	{
		this.message = message;
	}
}
