package servicio_json;

public class ParamOrdenaArticulo {
    int orden;
}
